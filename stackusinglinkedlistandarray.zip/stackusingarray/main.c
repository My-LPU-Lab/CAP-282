#include <stdio.h>
#include <stdlib.h>

int stack[5],max=5,top=1,item;

void pusharr(item)
{
    if(top==max)
    {
        printf("Stack is full. Insertion overflow");
    }else{
        top++;
        stack[top] = item;
    }
}
int main()
{
   // printf("Hello world!\n");
    int i=1,data;
    while(i<10)
    {
        printf("Enter data: ");
        scanf("%d",&data);
        pusharr(data);
        i++;
    }
    return 0;
}
