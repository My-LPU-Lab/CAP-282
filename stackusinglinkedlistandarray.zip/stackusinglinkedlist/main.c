#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node *next;
};
struct node *top, *newnode;


void pushstk(int item)
{
    newnode = (struct node*)malloc(sizeof(struct node));
    newnode->data = item;
    newnode->next=NULL;
    if(top==NULL)
    {
      top=newnode;
    }else{
       //struct node *temp;
       newnode->next=top;
       top = newnode;
    }


}

void isEmpty()
{
    if(top==NULL)
    {
        printf("No element in stack. Stack under flow");
    }
}

void popstk()
{
      isEmpty();
        struct node *temp;
        temp = top;
        top = temp->next;
        printf("The data pop out of stack is %d: ", temp->data);
        printf("\n");
        free(temp);

}



void display()
{
    struct node *temp;
    temp = top;
    isEmpty();
    printf("Element stored in stack are: ");
    while(temp!=NULL)
    {
      printf("%d ",temp->data);
      temp=temp->next;
    }
    //while()
}
int main()
{
    int item,option;

    while(1){
   printf("\nSelect Operation to Perfom.\n");
    printf("1.Push\n2.Pop\n3.Display\n4.Exit\n");
    printf("Answer: ");
    scanf("%d",&option);

        switch(option)
        {
        case 1:
            printf("Push Operation enter number: ");
            scanf("%d",&item);
            pushstk(item);
            break;
        case 2:
            //printf("\nPop element");
            popstk();
            break;
        case 3:
            printf("\n");
            display();
            printf("\n");
            break;
        case 4:
            exit(1);
        default:
            printf("No Option Selected");
        }
    }
    //popstk();
   // display();
    return 0;
}
