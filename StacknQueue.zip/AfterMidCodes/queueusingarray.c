#include <stdio.h>
#include <stdlib.h>


int arr_queue[5];

int ff = -1;
int rr = -1;

void nqueue(int input)
{
    int n = sizeof(arr_queue)/sizeof(int);
    //printf("%d",n);
    if(ff==0 && rr == n-1)
    {
        printf("Queue overflow.");
    }else if(ff==-1 && rr==-1){
        ff=rr=0;
        arr_queue[rr] = input;
    }else{

        rr++;
        arr_queue[rr] = input;

    }
}

void ddequeue()
{
    if(ff==-1 && rr == -1)
    {
        printf("Queue underflow");
    }else if(ff == rr){
        ff = rr = -1;
    }else{
        printf("The value dequeued is %d \n", arr_queue[ff]);
        ff++;
    }
}

void displayquee()
{
    int i;
if(ff==-1 && rr == -1)
    {
        printf("Queue underflow");
    }else{

        for(i=ff;i<rr+1;i++)
        {
            printf("%d ", arr_queue[i]);
        }
    }

}

int main()
{

  int j = 0,data2;

  do
  {
       printf("Enter data into queue: ");
      scanf("%d",&data2);
      nqueue(data2);
      j++;
  }while(j<5);

  displayquee();

//  peekitem();

  ddequeue();
  ddequeue();
  ddequeue();

  displayquee();
int k=0;
   do
  {
       printf("Enter data into queue: ");
      scanf("%d ",&data2);
      nqueue(data2);
      k++;
  }while(k<3);

    displayquee();
    return 0;

}

