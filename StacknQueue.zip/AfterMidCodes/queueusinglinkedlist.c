#include <stdio.h>
#include <stdlib.h>

struct queue
{
    int info;
    struct queue *link;

};
struct queue *front, *rear, *newnode;

void enqueue(int val)
{
    newnode = (struct queue*)malloc(sizeof(struct queue));
    newnode->info = val;
    newnode->link = NULL;

    if(front == NULL && rear == NULL)
    {
        front = newnode;
        rear = front;

    }else{
        rear->link = newnode;
        rear = newnode;

    }
}

void displaylist()
{
    struct queue *temp;
     printf("\nThe Items in the queue \n");
    if(front == NULL && rear == NULL)
    {
        printf("Queue is empty");
    }else{

        temp = front;
        while(temp!=NULL)
        {
            printf("%d ", temp->info);
            temp = temp->link;
        }

    }
}
void dequeue()
{
        struct queue *temp;

        temp = front;
        if(front == NULL && rear == NULL)
        {
            printf("Underflow Condition, Queue is empty");
        }else{
         front = front->link;
         free(temp);
        }
}

void peekfirst()
{
    //print first data. in FIFO
     printf("\nThe First Element the queue: \n");
    if(front == NULL && rear == NULL)
        {
            printf("\nUnderflow Condition, Queue is empty");
        }else{
                printf("%d", front->info);
        }

}
/*
int main()
{

  int j = 0,data1;

  do
  {
       printf("Enter data into queue: ");
      scanf("%d",&data1);
      enqueue(data1);
      j++;
  }while(j<10);

  displaylist();

  peekfirst();

  dequeue();

  displaylist();

    return 0;

}
*/
