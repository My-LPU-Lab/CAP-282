#include <stdio.h>
#include <stdlib.h>

int stack[100];
int maxtop=10, top=-1;

void push()
{
    int data;

    printf("Enter data on top of stack: ");
    scanf("%d",&data);
    if(top== maxtop)
    {
        printf("Stack Overflow");
    }else{
        top = top + 1;
        stack[top] = data;
    }
}

void pop()
{

    if(top == -1)
    {

        top--;
    }
}

void peek()
{
    int item;
    if(top == -1)
    {
        printf("Stack Underflow in Peek");
    }else{
        item =  stack[top];
        printf("\nItem on top of stack is %d", item);
    }

}

void display()
{
    int i;
    printf("\nItems in Stack: ");
    for(i=top; i>=0; i--)
    {
       printf("%d ",stack[i]);
    }
}
/*
int main()
{
  int j = 0;
  do
  {
      push();
      j++;
  }while(j<10);

  display();

  peek();

  pop();

  display();

    return 0;
}
*/
