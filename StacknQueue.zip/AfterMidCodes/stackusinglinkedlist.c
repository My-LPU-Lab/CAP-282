#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

struct stacknode
{
    int data;
    struct stacknode *next;
};
struct stacknode *topstk=NULL, *temp, *newnode;

void pushlist()
{
int item;
 printf("Enter data on top: ");
    scanf("%d", &item);
    newnode = (struct stacknode*)malloc(sizeof(struct stacknode));
    newnode->data = item;
    newnode->next = topstk;

    topstk = newnode;

}

void peektop()
{
    if (topstk == NULL)
    {
        printf("\nStack is empty");
    }else{
        printf("\nElement on top of stack is: %d", topstk->data);

    }
}

void poptop()
{
    temp = topstk;
    if(topstk == NULL)
    {
        printf("Stack is empty");
    }else{
        topstk = topstk->next;
        free(temp);
    }
}
void show()
{

temp = topstk;
    printf("\nData stored in stack list are");
    if (topstk == NULL)
    {
        printf("List is empty");
    }else{
    while(temp!=NULL)
    {
        printf(" %d ",temp->data);
        temp = temp->next;
    }

    }
}

/*
int main()
{

int j = 0;
  do
  {
      pushlist();
      j++;
  }while(j<10);

  show();
  peektop();
  poptop();



  show();


    return 0;
}

*/
